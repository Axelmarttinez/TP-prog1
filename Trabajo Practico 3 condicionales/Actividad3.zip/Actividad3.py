numero=int(input("ingresa un numero par"))
if numero %2==0:
    print("El numero es par")
else:
    print("el numero no es par")

