nota=float(input("Ingresa tu nota:"))
if nota >=6:
    print("Aprobado")
else:
    print("DEsaprobado")
    